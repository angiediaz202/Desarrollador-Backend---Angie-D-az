const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const cors = require('cors');
const fs = require('fs');

dotenv.config();
const app = express();
app.use(bodyParser.json());
app.use(cors());

let vehiculos = [];

// Función para leer datos del archivo JSON
function leerDatosDesdeJSON() {
  try {
    if (fs.existsSync('datos.json')) {
      const data = fs.readFileSync('datos.json');
      vehiculos = JSON.parse(data);
    } else {
      // Si el archivo no existe, crea un archivo vacío
      escribirDatosEnJSON([]);
    }
  } catch (error) {
    console.error('Error al leer datos desde el archivo JSON:', error);
  }
}

// Función para escribir datos en el archivo JSON
function escribirDatosEnJSON(data) {
  try {
    fs.writeFileSync('vehiculosData.json', JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Error al escribir datos en el archivo JSON:', error);
  }
}

// Rutas
app.get('/api/mapbox-token', (req, res) => {
  res.json({ token: process.env.MAPBOX_TOKEN });
});

app.get('/api/vehiculos', (req, res) => {
  res.json(vehiculos);
});

app.post('/api/vehiculos', (req, res) => {
  const vehiculo = req.body;
  vehiculo.ubicaciones = [vehiculo.ubicacion];
  vehiculos.push(vehiculo);
  escribirDatosEnJSON(vehiculos); // Guardar datos en el archivo JSON
  res.status(201).json(vehiculo);
});

app.put('/api/vehiculos/:id', (req, res) => {
  const { id } = req.params;
  const vehiculoActualizado = req.body;

  let vehiculo = vehiculos.find(v => v.id === id);
  if (vehiculo) {
    vehiculo.estado = vehiculoActualizado.estado;
    vehiculo.rendimiento = vehiculoActualizado.rendimiento;
    vehiculo.ubicaciones.push(vehiculoActualizado.ubicacion);
    escribirDatosEnJSON(vehiculos); // Guardar datos en el archivo JSON
    res.json(vehiculo);
  } else {
    res.status(404).json({ message: 'Vehículo no encontrado' });
  }
});

// Servir archivos estáticos
app.use(express.static('public'));

// Iniciar el servidor
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Servidor escuchando en el puerto ${port}`);
});

// Llamar a la función para leer datos desde el archivo JSON al iniciar el servidor
leerDatosDesdeJSON();
